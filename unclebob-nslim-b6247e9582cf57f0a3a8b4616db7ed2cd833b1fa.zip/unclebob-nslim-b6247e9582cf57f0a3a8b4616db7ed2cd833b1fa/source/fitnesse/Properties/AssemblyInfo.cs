﻿using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("FitNesse.NET")]
[assembly: AssemblyDescription("FitNesse.NET. The use and distribution terms for this software are covered by the Common Public License 1.0.")]
[assembly: AssemblyProduct("FitNesse.NET")]
[assembly: AssemblyCopyright("Copyright © Syterra Software Inc. All rights reserved.")]

[assembly: ComVisible(false)]

[assembly: AssemblyVersion("1.2.*")]
