﻿namespace fitnesse.sample {
    public class SampleDomain {
    }
}
